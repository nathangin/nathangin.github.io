from BoardClasses import *
import sys
sys.path.append("./AI_Extensions/")
from AI_Extensions import *
#from StudentAI import StudentAI
from StudentAI import StudentAI
from ManualAI import ManualAI
import argparse
import time
import cProfile
import pstats
from pstats import SortKey
class RunTests:
    def __init__(self,col,row,p,mode,debug):
        self.col = col
        self.row = row
        self.p = p
        self.mode = mode
        self.debug = debug
        self.ai_list = []

    def gameloop(self,fh=None):
        player = 1
        winPlayer = 0
        move = Move([])
        board = Board(self.col,self.row,self.p)
        board.initialize_game()
        if self.debug:
            board.show_board(fh)
        while True:
            try:
                move = self.ai_list[player-1].get_move(move)
                if(self.debug):
                    print("Player",player,"made move:",move)
                    if(board.tie_counter > 10): # game ends in tie if > 40 moves without a capture
                        print("tie countdown:", 40-board.tie_counter)
            except:
                import traceback
                print("Player",player,"crashed!",file=fh)
                traceback.print_exc(file=fh)
                if player == 1:
                    winPlayer = 2
                else:
                    winPlayer = 1
                break
            try:
                board.make_move(move, player)
            except InvalidMoveError:
                print("Invalid Move!",file=fh)
                if player == 1:
                    winPlayer = 2
                else:
                    winPlayer = 1
                break
            winPlayer = board.is_win(player)
            if self.debug:
                board.show_board(fh)
            if(winPlayer != 0):
                if self.mode == 'n': #Communicate with peer to tell the result.
                    if player == 1:
                        temp_player = 2
                    else:
                        temp_player = 1
                    if type(self.ai_list[temp_player - 1]) is NetworkAI:
                        self.ai_list[temp_player - 1].sent_final_result(move)
                break
            if player == 1:
                player = 2
            else:
                player = 1
        if self.mode == 'n' or self.mode == 'network' or self.mode == 'l' or self.mode == 'local':
            for AI in self.ai_list:
                if type(AI) is IOAI:
                    AI.close()
        return winPlayer

    def TournamentInterface(self):
        ai = StudentAI(self.col,self.row,self.p)
        while True:
            move = Move.from_str(input().rstrip())
            result = ai.get_move(move)
            print(result)

    '''
    The parameters should be changed DURING/AFTER the implementation of Board.
    '''

    def Run(self,fh=None,**kwargs):
        if self.mode == 'n' or self.mode == 'network' :
            if kwargs['mode'] == 'host':
                self.ai_list.append(
                    IOAI(self.col, self.row, self.p, ai_path=kwargs['ai_path'], time=kwargs['time']))
                self.ai_list.append(
                    NetworkAI(self.col, self.row, self.p, mode=kwargs['mode'], info=kwargs['info']))

            else:
                self.ai_list.append(
                    NetworkAI(self.col, self.row, self.p, mode=kwargs['mode'], info=kwargs['info']))
                self.ai_list.append(
                    IOAI(self.col, self.row, self.p, ai_path=kwargs['ai_path'], time=kwargs['time']))
            self.gameloop(fh)
        elif self.mode == 'm' or self.mode == 'manual' :
            self.ai_list.append(
                ManualAI(self.col, self.row, self.p))
            self.ai_list.append(
                IOAI(self.col, self.row, self.p, ai_path=kwargs['ai_path'], time=kwargs['time']))
            if kwargs['order'] != 1:
               self.ai_list.reverse() 
            
            self.gameloop(fh)
        elif self.mode == 's' or self.mode == 'self':
            if kwargs['order'] == '1':
                self.ai_list.append(
                    StudentAI(self.col, self.row, self.p))
                self.ai_list.append(
                    StudentAI(self.col, self.row, self.p))
            else:
                self.ai_list.append(
                    StudentAI(self.col, self.row, self.p))
                self.ai_list.append(
                    StudentAI(self.col, self.row, self.p))
            self.gameloop(fh)
        elif self.mode == 'l' or self.mode == 'local' :
            self.ai_list.append(
                IOAI(self.col, self.row, self.p, ai_path=kwargs['ai_path_1'], time=kwargs['time']))
            self.ai_list.append(
                IOAI(self.col, self.row, self.p, ai_path=kwargs['ai_path_2'], time=kwargs['time']))
            return self.gameloop(fh)
        elif self.mode == 't':
            self.TournamentInterface()


if __name__ == "__main__":
# Command to run from cmdline:
# be in the Checkers-171 directory
# 
# Optional Parameters:
# python ./src/checkers-python/RunTests.py [amount, [AI1, AI2]]
    GOOD_AI = './Tools/Sample_AIs/Good_AI/main.py' 
    POOR_AI = './Tools/Sample_AIs/Poor_AI/main.py'
    AVERAGE_AI = "./Tools/Sample_AIs/Average_AI/main.py"
    RANDOM_AI ='./Tools/Sample_AIs/Random_AI/main.py'  
    STUDENT_AI =  './src/checkers-python/main.py'
    MANUAL_PLAYER = "MANUAL_PLAYER"
    DEBUG = False
    
    def ai_to_str(AI_PATH):
        if(AI_PATH == GOOD_AI):
            return "GOOD_AI"
        elif(AI_PATH == AVERAGE_AI):
            return "AVERAGE_AI"
        elif(AI_PATH == POOR_AI):
            return "POOR_AI"
        elif(AI_PATH == RANDOM_AI):
            return "RANDOM_AI"
        elif(AI_PATH == STUDENT_AI):
            return "STUDENT_AI"
        elif(AI_PATH == MANUAL_PLAYER):
            return "MANUAL_PLAYER"
    # handle arguments
    def choose_ai(AI):
        AI = AI.lower()
        if(AI.startswith("p")):
            return POOR_AI
        elif(AI.startswith("r")):
            return RANDOM_AI
        elif(AI.startswith("g")):
            return GOOD_AI
        elif(AI.startswith("a")):
            return AVERAGE_AI
        elif(AI.startswith("s")):
            return STUDENT_AI
        elif(AI.startswith("m")):
            return MANUAL_PLAYER
        else:
            print("UNKNOWN AI TYPE:", AI.capitalize())
            raise Exception("RunTests unknown AI Type:", AI.capitalize())
    parser = argparse.ArgumentParser(
        prog = "AI Tester",
        description = "Tests various AI against eachother.",
        epilog= "Code adapted from GameLogic.py by Team 99 (Eric X and Nathan G) for ICS 171"
        )
    parser.add_argument("amount", nargs="?", type=int, default=10)
    parser.add_argument("player_one", nargs="?", default="Random_AI")
    parser.add_argument("player_two", nargs="?", default="Student_AI")
    parser.add_argument("-d", "--debug", action="store_true")
    parser.add_argument("-p", "--profile", action="store_true")
    args = parser.parse_args()

    DEBUG = args.debug
    PROFILE = args.profile


    if PROFILE:
        print("Profiling StudentAI!")
        def run_profile(col, row, k):
            main = RunTests(col, row, k, "s", debug = False)
            result = main.Run(mode="s", order=1)
            print(result)
        cProfile.run("run_profile({}, {}, {})".format(8, 8, 3), filename="profile_stats")
        stats = pstats.Stats('profile_stats')
        stats.strip_dirs().sort_stats(SortKey.CUMULATIVE).print_stats(20);

        exit()
    
    # run tests
    def run_local_test(col, row, k, ai_path_1, ai_path_2):
        main = RunTests(col, row, k, "l", debug=DEBUG)
        start_time = time.time()
        result = main.Run(mode="l", ai_path_1=ai_path_1, ai_path_2=ai_path_2, time=1200)
        end_time = time.time()
        elapsed_time = end_time - start_time
        return result, elapsed_time

    def run_manual_test(col, row, k, ai_path_1, ai_path_2):
        main = RunTests(col, row, k, "m", debug=True)
        start_time = time.time()
        if ai_path_1 == MANUAL_PLAYER:
            ai_path = ai_path_2
            order = 0
        else:
            ai_path = ai_path_1
            order = 1
        if ai_path_1 == ai_path_2 == MANUAL_PLAYER:
            raise Exception("Cannot have two manual players!")
        result = main.Run(mode="m", ai_path=ai_path, order=order, time=1200)
        end_time = time.time()
        elapsed_time = end_time - start_time
        return result, elapsed_time
    
    total_time = 0
    wins = 0
    losses = 0
    ties = 0
    reversed = False
    amount = args.amount
    PLAYER_ONE = choose_ai(args.player_one)
    PLAYER_TWO = choose_ai(args.player_two)
    _PLAYER_ONE, _PLAYER_TWO = PLAYER_ONE, PLAYER_TWO
    print("PLAYER ONE:", PLAYER_ONE)
    print("PLAYER TWO:", PLAYER_TWO)
    print("TOTAL GAMES:", amount)
    for i in range(amount):
        print("[--[--BLACK--]--]:", ai_to_str(_PLAYER_ONE) +"-"+("1" if not reversed else "2"))
        print("{~~{~~WHITE~~}~~}:", ai_to_str(_PLAYER_TWO) +"-"+("1" if reversed else "2"))
        if MANUAL_PLAYER in (PLAYER_ONE, PLAYER_TWO):
            print("Starting Manual Game No.", i + 1)
            result, elapsed_time = run_manual_test(8, 8, 3, _PLAYER_ONE, _PLAYER_TWO)
        else:
            print("Starting Local Game No.", i + 1)
            result, elapsed_time = run_local_test(8, 8, 3, _PLAYER_ONE, _PLAYER_TWO)

        total_time += elapsed_time

        if result == -1:
            ties += 1
        else:
            if reversed:
                result = 3 - result
            if result == 2:
                wins += 1
                print("{} Won!".format(ai_to_str(PLAYER_TWO)))
            elif result == 1:
                losses += 1
                print("{} Won!".format(ai_to_str(PLAYER_ONE)))
            else:
                print("Tie!")

        _PLAYER_ONE, _PLAYER_TWO = _PLAYER_TWO, _PLAYER_ONE
        reversed = not reversed

        # Print results for each game
        print(f"Game {i + 1} - Elapsed Time: {elapsed_time:.2f} seconds | Result: {result}")

    # Print overall results and total time
    print("\n=== OVERALL RESULTS === \n")
    print("{:>10s}-1:".format(ai_to_str(PLAYER_ONE)), losses)
    print("{:>10s}-2:".format(ai_to_str(PLAYER_TWO)), wins)
    print("{:>12s}:".format("TIES"), ties)
    print("{:>12s}:".format("RATIO"), (losses) / max(1, losses + wins))
    print("Total time for all games: {:.2f} seconds".format(total_time))
