from random import randint
from BoardClasses import Move
from BoardClasses import Board

# our imports
import sys
import math
import copy
from abc import ABCMeta, abstractmethod
from concurrent.futures import as_completed, ProcessPoolExecutor, ThreadPoolExecutor
from threading import Thread, Lock
import time
#The following part should be completed by students.
#Students can modify anything except the class name and exisiting functions and variables.

class StudentAI():
    def __init__(self,col,row,p):
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col,row,p)
        self.board.initialize_game()
        self.opponent = {1:2,2:1}
        self.color = 2
        self.turns = 0
        # self.scheme = RandomMove(self.board)
        self.backup_scheme = StallHeuristic(self.board)
        self.scheme = MonteCarlo(self.board, **MONTE_CARLO_PROPERTIES)
        #self.backup_scheme = MonteCarlo(self.board, **FAST_MONTE_CARLO_PROPERTIES)
        if(not isinstance(self.scheme, Scheme)):
            raise Exception("StudentAI is not using a valid scheme!")
        if(not isinstance(self.backup_scheme, Scheme)):
            raise Exception("StudentAI is not using a valid backup scheme!")
        self.total_time = 0
        safe_print("StudentAI Initialized!", level=2)

    def get_move(self, move):
        start_time = time.time()
        if len(move) != 0:
            self.board.make_move(move,self.opponent[self.color])
            safe_print("Student AI Opponent Made Move:", move, "as", player_to_color(opponent(self.color)), 
                level=2)
            safe_print(self.board, level=2)
        else:
            self.color = 1
        self.scheme.set_player(self.color)
        best_move = None
        if(not self.overtime()):
            best_move = self.async_timed_scheme(start_time=start_time, scheme=self.scheme, move=move)
        if(not best_move or self.overtime()):
            self.backup_scheme.set_player(self.color)
            best_move = self.backup_scheme.get_best_move(self.board, move)
        self.board.make_move(best_move, self.color)
        self.total_time += time.time() - start_time
        safe_print("total time elapsed: {:.2f}".format(self.total_time))
        self.turns += 1
        safe_print("exchange no.", self.turns)
        safe_print("Student AI Made Move:", best_move, "as", player_to_color(self.color), level=2)
        safe_print(self.board, level=2)
        return best_move

    def async_timed_scheme(self, start_time, scheme, move):
        lock = Lock()
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(scheme.get_best_move, self.board, move)
            while(not future.done()):
                time.sleep(0.1) # wait 
                total_time = self.total_time + time.time() - start_time
                safe_print("Waiting on result for", future, "current time:", total_time, level=0)
                safe_print("overtime:", self.overtime(total_time), level=0)
                if(self.overtime(total_time) and not future.done()):
                    lock.acquire(True)
                    safe_print("Entered overtime while in execution!", level=2)
                    scheme.cancel()
                    lock.release()
                    return False 
            safe_print("current time: {:.2f}".format(self.total_time + time.time() - start_time), level=0)
            return future.result()


    def elapsed_time(self):
        return time.time() - self.start_time

    def overtime(self, time=None) -> bool:
        if(time is None):
            total_time = self.total_time
        else:
            total_time = time
        return False if (total_time < MAX_TIME - OVERTIME and self.turns < OVERTIME_TURNS) else True


##############################
#       Atomic Helpers       #
##############################

def get_random_move(board, player, moves=None):
    # random search
    # safe_print("get_random_move")
    if(moves is None):
        moves = board.get_all_possible_moves(player)
    piece = randint(0,len(moves)-1) ## RANDOM
    piece_move =  randint(0,len(moves[piece])-1) ## RANDOM
    return moves[piece][piece_move]

def get_heuristic_move(board, player, heuristic: "Heuristic", moves=None):
    if(moves is None):
        moves = board.get_all_possible_moves(player)
    # safe_print("get_heuristic_move", board, player, moves, heuristic)
    best_moves = [moves[0][0]]
    best_move_value = float('-inf')
    for piece in range(len(moves)):
        for move in range(len(moves[piece])):
            move_value = heuristic_evaluate(board, moves[piece][move], player, heuristic) 
            # Make the move --> evaluate board --> undo
            if(move_value > best_move_value):
                best_moves = [moves[piece][move]]
                best_move_value = move_value
            elif(move_value == best_move_value):
                best_moves.append(moves[piece][move])

    #safe_print("*best moves chosen was:", best_moves, "with a score of:", best_move_value)
    return best_moves[randint(0, len(best_moves)-1)]


def heuristic_evaluate(board, move, player, heuristic: "Heuristic"):
    # safe_print("\tevaluate_move")
    board.make_move(move, player)
    score = heuristic.calculate_board(board, player)
    board.undo()
    return score


# returns the opponent player (1 -> 2, 2 -> 1)
def opponent(player):
    return 3-player

# returns if timed out or not
def _is_timeout(start_time, timeout) -> bool:
    return (not(timeout is None) and ((time.time() - start_time) > timeout))


# returns the color corresponding to the player #
def player_to_color(player:int) -> str:
    if(player == 1):
        return "black"
    elif(player==2):
        return "white"
    else:
        raise Exception("player_to_color: invalid player {}".format(player))

# prints/writes to log depending on configuration
def safe_print(*args, end="\n", level=1):
    if(level < LOG_LEVEL):
        return
    if(SAFE):
        if(len(args)>0 and isinstance(args[0], Board)):
            args[0].show_board()
        else:
            print(*args, end=end)
    if(LOG_FILE):
        if(len(args)>0 and isinstance(args[0], Board)):
            args[0].show_board(fh=LOG_FILE)
        else:
            print(*args, file=LOG_FILE, end=end)
        LOG_FILE.flush() # write contents of buffer
        return

def _simulate_random_game(player, board, index=None):
    #safe_print(board.is_win(player))
    while board.is_win(player) == 0:
        moves = board.get_all_possible_moves(player)
        if not moves:
            return 0, index
        move = get_random_move(board, player, moves)
        board.make_move(move, player)
        # safe_print("\tmade move:", move)
        player = opponent(player)
        # safe_print("\tcurrent_player:", player)
    # safe_print("Win result:", board.is_win(player))
    # safe_print(board)
    return board.is_win(player), index

def equal_boards(board, other) -> bool:
    if len(board) != len(other):
        return False
    if len(board[0]) != len(other[1]):
        return False
    for i in range(len(board)):
        for j in range(len(board[i])):
            if not board[i][j].color == other[i][j].color:
                return False
    return True

###############################
#     Expansion Policy ABC    #
###############################

class ExpansionPolicy(metaclass=ABCMeta):
    
    get_move = None # function(board, player, [moves]) -> valid move

    @classmethod
    def policy(cls, player, board, moves=None, index=None) -> "win_result, index":
        # safe_print("ExpansionPolicy.policy:", cls, player, board, index)
        board = copy.deepcopy(board)
        if(cls.get_move is None):
            raise NotImplementedError()
        #safe_print(board.is_win(player))
        #safe_print("starting position of", cls.__name__)
        while board.is_win(player) == 0:
            if(moves is None):
                moves = board.get_all_possible_moves(player)
            if not moves:
                return opponent(player), index # case for no moves possible from a position
            move = cls.get_move(board, player, moves)
            # safe_print("attempting to make move:", move)
            board.make_move(move, player)
            #safe_print("\tcurrent_player:", player)
            #safe_print("\tmade move:", move)
            #safe_print(board)
            player = opponent(player)
            moves = None
        # safe_print("Win result:", board.is_win(player))
        result = board.is_win(player), index
        del board
        return result

##############################
#         Scheme ABC         #
##############################

class Scheme(metaclass=ABCMeta):
    def __init__(self, board):
        name = self.__class__.__name__
        self.name = name
        self.board = board
        self.cancelled = False
        safe_print("Scheme initialized:", name)

    def set_player(self, player):
        self.player = player

    def cancel(self, cancel = True):
        self.cancelled = cancel

    @abstractmethod
    def get_best_move(self, board: "Board", last_move=None) -> "move":
        """
        this function returns the best move given a current board state
        @param board: Board object with current state
        @return move: move object
        """
        raise NotImplementedError()       

####################################
#       Heuristic Functions        #
####################################

class RandomMove(Scheme):
    def get_best_move(self, board: "Board"):
        return get_random_move(board, self.player)

class Heuristic(Scheme): 
    # takes boardstate and returns a number
    def evaluate(self, board: Board, player) -> float:
        # safe_print("Heuristic evaluate")
        """
        this function returns the heuristic evaluation of any board state
        @param board: Board object with current state
        @param player: player to evaluate as (1 = black, 2 = white)
        @return heuristic_value: float representing how good the current state is
        """
        if(board.is_win(player)):
            return sys.maxsize # maximum
        return self.__class__.calculate_board(board, self.player)
    
    def get_best_move(self, board: "Board",last_move = None):
        # safe_print("get_best_move_with_heuristic: ", self.name)
        return get_heuristic_move(board, self.player, self.__class__)

    @staticmethod
    def evaluate_move(self, board, move):
        return heuristic_evaluate(board, move, self.player, self.__class__)

    @abstractmethod
    def calculate_board(board, player):
        return NotImplementedError()

class PieceHeuristic(Heuristic): # values own pieces vs. enemy
    # calculates the heuristic based on positions
    @staticmethod
    def calculate_board(board, player):
        # safe_print("pieceHeuristic calculate_board")
        board_evaluation = 0
        # loop through board
        for row in range(board.row):
            for col in range(board.col):
                checker = board.board[row][col]
                piece_score = 0
                if(checker.color != "."):
                    piece_score += 25
                    if(checker.is_king):
                        piece_score += 50
                if (player == 1 and checker.color == "W"):
                    piece_score *= -1 # Neg 1 vs Pos 1
                elif (player == 2 and checker.color == "B"):
                    piece_score *= -1
                board_evaluation += piece_score
        return board_evaluation

class StallHeuristic(Heuristic): # values available moves and total pieces
    @staticmethod
    def calculate_board(board, player):
        # safe_print("StallHeuristic calculate_board")
        board_evaluation = 0
        total_moves = len(board.get_all_possible_moves(player)) \
            + len(board.get_all_possible_moves(opponent(player)))
        board_evaluation += total_moves * 50
        for row in range(board.row):
            for col in range(board.col):
                checker = board.board[row][col]
                piece_score = 0
                if(checker.color != "."):
                    piece_score += 25
                    if(checker.is_king):
                        piece_score += 100
                board_evaluation += piece_score
        return board_evaluation

########################################
#        Policy Implementations        #
########################################

class RandomPolicy(ExpansionPolicy):
    get_move = get_random_move

class HeuristicPolicy(ExpansionPolicy):
    hueristic = PieceHeuristic

    @classmethod
    def _heuristic_policy_exec(cls, board, player, moves):
        if(randint(0, 100) < 25):
            return get_heuristic_move(board, player, cls.heuristic, moves=moves)
        else:
            return get_random_move(board, player, moves)
    get_move = _heuristic_policy_exec

class StallPolicy(HeuristicPolicy):
    heuristic = StallHeuristic

class DeterministicPolicy(ExpansionPolicy):
    # policy for testing that alternates the results
    @classmethod
    def policy(cls, player, board, index=None):
        return (1 if index %2 else 2), index


############################
#       Monte Carlo        #
############################
class MonteCarlo(Scheme):
    MCTree = None # MCTree is shared by all MonteCarlo schemes
    last_node = None
    def __init__(self, board, optimism = 1.141, iterations=500, timeout=None, repeats=1, expansion_policy=RandomPolicy):
        self.optimism = optimism
        self.iterations = iterations
        self.timeout = timeout
        self.root = None
        self.repeats=repeats
        if(not type(expansion_policy) == type(ExpansionPolicy) and not(expansion_policy is None)):
            raise Exception("MonteCarlo is not using a valid expansion policy: " \
                + str(type(expansion_policy)))
        self.MCTreeProperties = {"curiosity": optimism, "expansion_policy": expansion_policy}
        super().__init__(board) 

    def get_best_move(self, board, last_move=None):
        # scheme setup (for first move)
        if(self.root is None):
            if(self.__class__.MCTree is None):
                self.root = MCNode("root", player=self.player, board=self.board)
                self.__class__.MCTree = MonteCarloTree(root=self.root, **self.MCTreeProperties)
                self.__class__.last_node = self.root
            else:
                self.root = self.__class__.last_node.parent or self.__class__.last_node
                safe_print("Initialized a new MonteCarlo Scheme!")
        # operation
        last_node = self.__class__.last_node
        self.cancel(False)
        self.simulate(last_node, 1) # ensure children exist
        # safe_print(self.board)
        if(last_node is self.root):
            current_node = last_node
        else:
            current_node = last_node.find_child(self.board, move=last_move)
        safe_print("Simulating", self.iterations, "nodes" \
            + " with {} repeats".format((self.repeats)) if self.repeats != 1 else "")
        success = self.simulate(current_node, max(self.iterations, 1), timeout=self.timeout)
        safe_print("nodes available:\n", *[str(child)+"\t\n" for child in current_node.children])
        if(self.cancelled):
            safe_print("MonteCarlo.simulate was cancelled!")
            return last_move
        lock = Lock()
        lock.acquire(True)
        best_node = current_node.get_best_node()
        if(best_node is None):
            moves_left_str = " while there were " \
                + len(current_node.board.get_all_possible_moves(self.player)) \
                + " moves left!"
            raise Exception("MonteCarlo returned no move from node: " + str(last_node) + moves_left_str)
        safe_print("node chosen:", str(best_node), level=2)
        self.__class__.last_node = best_node
        del best_node.parent.parent
        best_node.parent.parent = None # delete the parent to save on memory
        lock.release()
        return best_node.move

    def simulate(self, current_node, iterations, timeout=None):
        # self.MCtree = MonteCarloTree(root=self.root, **self.MCTreeProperties)
        total_expansions = 0
        start_time = time.time()
        success = True
        for i in range(iterations):
            success = self.__class__.MCTree.expand_node(current_node, repeats=self.repeats)
            if(not success or _is_timeout(start_time, timeout) or self.cancelled):
                break 
            total_expansions += 1
        safe_print("Expanded {} nodes of target {}".format(total_expansions, iterations))
        if(not success or timeout is None):
            safe_print("Ended early due to success = ", success, \
                ", _is_timeout =", _is_timeout(start_time, timeout), level=0)
            return True
        elif(self.cancelled):
            safe_print("Ended early due to cancellation.", level=0)
            return False
        elif(_is_timeout(start_time, timeout)):
            safe_print("timed out during calculation", level=0)
            return True
        safe_print("\tUsing additional time to expand nodes...")
        total_expansions = 0
        while(not _is_timeout(start_time, timeout)):
            success = self.__class__.MCTree.expand_node(current_node, repeats=self.repeats)
            if(not success or self.cancelled):
                success = False
                break 
            total_expansions += 1
        safe_print("\tExpanded {} additional nodes in remaining time!".format(total_expansions, iterations))
        return success

    
    # Choose best move from depth of two after 100 iterations. Take the best move then take their move as the new route
    # Simulate x iterations using get_next_move

###################################
#       Tree Implementation        #
####################################
class Node:
    def __init__(self, id, parent = None, player = None):
        self.id = id  
        self.parent = parent
        if player == None:
            self.player = {1:2, 2:1}[parent.player] if parent != None else 1
        else:
            self.player = player
        self.children = []
        self.wins = 0
        self.losses = 0


    def add_child(self, child_id):
        child_node = Node(child_id, parent = self, player = opponent(self.player))
        self.children.append(child_node)
        return child_node
    
    def add_children(self, *children):
        for child in children:
            child.parent = self
            child.player = opponent(self.player)
        self.children.extend(children)
        return
    
    def add_win(self, amount = 1):
        if self.parent:
            self.parent.add_loss(amount)
        self.wins += amount
        return
    
    def add_loss(self, amount = 1):
        if self.parent:
            self.parent.add_win(amount)
        self.losses += amount
        return
    
    def win_rate(self) -> float:
        win_rate = self.wins/max(self.losses + self.wins, 1)
        # return (1-win_rate) if self.player == 2 else win_rate
        return win_rate

    def get_best_node(self) -> "Node":
        if(len(self.children) > 0):
            selection = max(self.children, key = lambda child: child.win_rate())
            return selection
        else:
           return None
    
    def handle_win_result(self, win_result):
        if win_result == -1: # tie
            self.add_win()
        elif win_result == 0: # current player cannot make a move
            # safe_print("cannot make move")
            self.add_loss()
        else: # white wins = 2, black wins = 1
            win_result = self.player == win_result
            if win_result:
                self.add_win()
            else:
                self.add_loss()
     
    def get_total_runs(self):
        return self.wins + self.losses

    def __eq__(self, other):
        return self.win_rate() == other.win_rate()
    
    def __lt__(self, other):
        return self.win_rate() < other.win_rate()

    def __ne__(self, other):
        return not self == other
    
    def __ge__(self, other):
        return not self < other
    
    def __gt__(self, other):
        return other < self

    def __le__(self, other):
        return not self.__gt__(other)
    
    def __str__(self):
        minimax_status = "" if self.player is None else ("m" if self.player == 2 else "M")
        win_loss = {"wins":self.wins, "losses":self.losses}
        return "[{minimax}{id: ^5}:{wins: >4}/{losses: >4}]".format(minimax = minimax_status, id=self.id, 
            **win_loss)
    
class MCNode(Node):
    def __init__(self, id, parent = None, player = None, board = None, move = None):
        super().__init__(id, parent, player)
        self.move = move
        if parent is None and board is None:
            raise Exception("no board information for Node")
        elif not board is None:
            self.board = board

    def add_child(self, child_id, move):
        self.board.make_move(move, self.player)
        new_board = copy.deepcopy(self.board)
        child_node = MCNode(child_id, parent = self, move = move,
            board = new_board, player=opponent(self.player))
        self.children.append(child_node)
        self.board.undo()
        return child_node

    def _simulate_test(self) -> bool:
            # simulate a game from the current board state randomly and return win/loss
            win = randint(0, 1)
            if(win):
                self.add_win()
            else:
                self.add_loss()
            return win

    def simulate_random_game(self) -> bool:
        # safe_print("simulating random game!")
        # simulate a random game until the is_win is true or there are no more moves and false (lose)
        current_player = self.player
        new_board = copy.deepcopy(self.board) 
        win_result = _simulate_random_game(current_player, new_board)[0] 
        self.handle_win_result(win_result)
        
       
    # return the child node that matches the board state or move
    def find_child(self, board, move=None):
        if(move is None):
            safe_print("finding child with board:", level=0)
            safe_print(board, level=0)
            for child in self.children:
                safe_print(child, level=0)
                safe_print("child board:", level=0)
                safe_print(child.board, level=0)
                if equal_boards(child.board.board, board.board):
                    return child
        elif(move != None):
            safe_print("finding child with move", level=0)
            safe_print(move, level = 0)
            for child in self.children:
                if(str(child.move) == str(move)):
                    return child
        safe_print("Find child exception:", move, "children:", 
            *["\n\t"+str(child) for child in self.children])
        raise Exception("Could not find matching child from board state.")

class MonteCarloTree: # class for managing a MonteCarloTree
    def __init__(self, root = None, curiosity = 1.414, expansion_policy = RandomPolicy):
        self.root = root
        self.exploration_parameter = curiosity # according to online sources ideal is sqrt(2) ~= 1.414 
        self.expansion_policy = expansion_policy

    def get_next_move(self, node = None):
        # gets the next best move from a node
        try:
            if(node is None):
                node = self.root
            safe_print(node.id)
            best_node = node.get_best_node() # winrate is based on the node's current player
            if(best_node is None):
                raise ValueError("No more nodes left!")
            return best_node.move
        except ValueError:
            raise Exception("Out of moves:")

    def expand_node(self, node: "MCNode", repeats=1) -> bool:
        """
        expands the current node following the given MonteCarlo expansion policy.
        Returns a boolean value indicating if the node was expanded or if it was cancelled
        optional repeats value to propagate extra times
        """
        # Get the deepest child node with the highest UTC value
        while len(node.children) > 0:
            node = max(node.children, key=lambda child: self.calculate_UCT(child))
        # expand a leaf node if it is not in a win/lose state
        all_moves = node.board.get_all_possible_moves(node.player)
        if(node.board.is_win(node.player) or len(all_moves) == 0):
            node.handle_win_result(node.board.is_win(node.player))
            return True
        elif len(all_moves) == 1 and len(all_moves[0]) == 1:
            safe_print(node, "has only one available option, expanding it...", level=0)
            node = node.add_child(child_id=str(all_moves[0][0]), move=all_moves[0][0])
            return self.expand_node(node=node, repeats=repeats)
        # multiprocessing propagation with concurrent.futures
        futures = list()
        with ProcessPoolExecutor() as batman:
            index = 0
            for piece_moves in range(len(all_moves)):
                piece = piece_moves
                for move in range(len(all_moves[piece_moves])):
                    # add the result of the move as a deep copied board as 
                    # child of the node
                    chosen_move = all_moves[piece][move]
                    safe_print("expanding node with move:", chosen_move, level=0)
                    # TODO add better way to handle child ids or get rid of ids
                    new_child = node.add_child(child_id=str(chosen_move), move=chosen_move)
                    safe_print("Adding task to node:", new_child, level=0)
                    moves = new_child.board.get_all_possible_moves(new_child.player)
                    for i in range(repeats):
                        result = \
                            batman.submit(self.expansion_policy.policy, 
                            player=new_child.player, board=new_child.board, moves=moves, index=index)
                        futures.append(result)
                    index += 1
                    safe_print("waiting on win result:", result, level=0)
            try:
                for future in as_completed(futures, timeout=10):
                    result, index = future.result()
                    node.children[index].handle_win_result(result)
                    safe_print("handled win result", result, node.children[index], level=0)
            except(TimeoutError):
                safe_print("Timed out while waiting for a node to expand.")
        return True

    def calculate_UCT(self, node):
    # UCT = parent win rate + exploration parameter * sqrt(log(parent's simulations)/this node's simulations)
        return node.parent.win_rate() +\
            self.exploration_parameter * math.sqrt( math.log(\
                max(1, node.parent.wins + node.parent.losses), math.e) / max(1, node.wins + node.losses))

    @staticmethod
    def print_tree(node, depth = 0):
        if node is None:
            return
        safe_print(str(node))
        total_children = len(node.children)
        for child in range(total_children):
            safe_print("│  " * depth, end="")
            safe_print("├──" if child < total_children - 1 else "└──", end="")
            MonteCarloTree.print_tree(node.children[child],  depth+1)

    @staticmethod
    def _loadMonteCarloTree(node): 
        """
        Initializes a file to write/read previous MCTree results
        """
        # Deprecated: according to ed discussion we can't cache results between games
        # original plan was to use the shelve module to store the whole thing...
        return None

#CALCULATE KINGS, and middle control
#Starts at -25 which is odd after first move. Moves pieces to middle but does not push for king. 
#Make board.board into string and put into hash table.

def close_file_after(seconds, file):
    time.sleep(seconds) # wait 
    safe_print("{} seconds reached, closed log file {}".format(seconds, file.name), level=5)
    file.close()

#################################################
#                PROGRAM SETUP                  #
#################################################

MAX_TIME = 300 # 5 minute total for each player (300 seconds)
OVERTIME = 5 # switch to overtime when there is only 45 seconds left
OVERTIME_TURNS = 40 # switch to overtime when over 35 turns

TIMEOUT = (MAX_TIME-OVERTIME)/OVERTIME_TURNS # target time for MonteCarlo
REPEATS = 8 # optional >1 repeats for each expansion (more time-efficient due to multiprocessing)
MONTE_CARLO_PROPERTIES = {"iterations":100, "expansion_policy": RandomPolicy,
    "timeout":TIMEOUT, "repeats": REPEATS}
FAST_MONTE_CARLO_PROPERTIES = {"iterations":15, "expansion_policy": StallPolicy, 
    "timeout": 1, "repeats": 2}

# SAFE = 0 -> don't print to output
# LEVEL = the level of output to print
# DO_LOG => output to log file
SAFE = 0
LOG_LEVEL = 1
DO_LOG = False
LOG_FILE = None
# prints to output only if it is safe
if(DO_LOG and not LOG_FILE):
    current_time = time.strftime("%H:%M:%S", time.localtime())
    current_day = time.strftime("%a_%d_%b_%Y", time.localtime())
    LOG_FILE_PATH = "Student_AI_Log-{day}@{time}.log".format(day=current_day, time=current_time)
    # print("Writing output to:", LOG_FILE_PATH)
    LOG_FILE = open(LOG_FILE_PATH, "w")
    thread = Thread(target = close_file_after, args=[1200, LOG_FILE]) # using 1200 instead of MAX_TIME
    thread.daemon = True
    thread.start()
    safe_print("Log File {} created!".format(LOG_FILE.name))


####################################
#             Testing              #
####################################
# to test: python ./src/checkers-python/StudentAi.py
if __name__ == "__main__":
    print("Please use RunTests or StudentAITests to test!")
