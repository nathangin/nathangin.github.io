from StudentAI import *
import unittest

class Test_NodeClass(unittest.TestCase):
    def setUp(self):
        self.A = Node(1)
        self.B = Node(2)
        self.C = Node(3)
        self.D = Node(4)
        self.A.wins = 5
        self.B.wins = 5
        self.D.wins = 10
        self.D.losses = 10
        self.C.wins = 5
        self.C.losses = 10

    def test_NodeWinrate(self):
        A = self.A
        B = self.B
        C = self.C
        D = self.D
        self.assertEqual(A.win_rate(), 1)
        self.assertEqual(B.win_rate(), 1)
        self.assertAlmostEqual(D.win_rate(), 0.5)
        self.assertAlmostEqual(C.win_rate(), 1/3)

    def test_NodeComparisons(self):
        A = self.A
        B = self.B
        C = self.C
        D = self.D
        self.assertTrue(A == B)
        self.assertTrue(A.wins == 5)
        self.assertTrue(B.wins == 5)
        self.assertTrue(C.wins == 5)
        self.assertTrue(D.wins == 10)
        self.assertTrue(D > C)
        self.assertTrue(A >= B)
        self.assertTrue(A <= B)
        self.assertTrue(C <= D)

    def tearDown(self):
        return

class Test_MonteCarloTreeClass(unittest.TestCase):
    def setUp(self):
        ARoot = Node(1)
        A = MonteCarloTree(ARoot)
        A.root = ARoot
        #  MAX        (A)
        #            /   \
        #  MIN     (B)   (C)
        #         /   \     \
        #  MAX   (D)  (E)___   (F)________
        #         |  /   |  \     \  \     \
        #  MIN   (G) (H) (I) (K)(J) (L)   (M)______________
        #        / \      |     /|     \     \     \       \
        #  MAX (N) (O)   (P) (Q) (R)    (S)  (T)   (U)    (V)

        nodes = {}
        board = Board(8, 8, 3)
        board.initialize_game()
        for letter in "ABCDEFGHIJKLMNOPQRSTUV":
            nodes[letter] = MCNode(letter, board=board, player = 1)

        nodes['A'].add_children(nodes['B'], nodes['C'])
        nodes['B'].add_children(nodes['D'], nodes['E'])
        nodes['C'].add_children(nodes['F'])
        nodes['D'].add_children(nodes['G'])
        nodes['E'].add_children(nodes['H'], nodes['I'], nodes['K'])
        nodes['F'].add_children(nodes['J'], nodes['L'], nodes['M'])
        nodes['G'].add_children(nodes['N'], nodes['O'])
        nodes['I'].add_children(nodes['P'])
        nodes['J'].add_children(nodes['Q'], nodes['R'])
        nodes['L'].add_children(nodes['S'])
        nodes['M'].add_children(nodes['T'], nodes['U'], nodes['V'])

        nodes['N'].add_win(10)
        nodes['O'].add_win(9)
        nodes['P'].add_win(8)
        nodes['Q'].add_win(7)
        nodes['R'].add_win(6)
        nodes['S'].add_win(5)
        nodes['T'].add_win(4)
        nodes['U'].add_win(3)
        nodes['V'].add_win(2)
        nodes['H'].add_win(2)
        nodes['K'].add_win(2)

        nodes['N'].add_loss(2)
        nodes['O'].add_loss(3)
        nodes['P'].add_loss(4)
        nodes['Q'].add_loss(5)
        nodes['R'].add_loss(1)
        nodes['S'].add_loss(6)
        nodes['T'].add_loss(7)
        nodes['U'].add_loss(8)
        nodes['V'].add_loss(9)
        nodes['H'].add_loss(3)
        nodes['K'].add_loss(100)
        self.nodes = nodes
        self.MCTree = MonteCarloTree(nodes['A'])
    
    def test_MCTree_Setup(self):
        nodes = self.nodes
        MCTree = self.MCTree
        self.assertEqual (nodes['N'].wins, 10)
        self.assertEqual (nodes['N'].losses, 2)

        self.assertEqual (nodes['G'].wins, 5)
        self.assertEqual (nodes['G'].losses, 19)
        self.assertEqual (nodes['I'].wins, 4)
        self.assertEqual (nodes['I'].losses, 8)
        self.assertEqual (nodes['J'].wins, 6)
        self.assertEqual (nodes['J'].losses, 13)
        self.assertEqual (nodes['L'].wins, 6)
        self.assertEqual (nodes['L'].losses, 5)
        self.assertEqual (nodes['M'].wins, 24)
        self.assertEqual (nodes['M'].losses, 9)
        self.assertEqual (nodes['F'].wins, 27)
        self.assertEqual (nodes['F'].losses, 36)
        self.assertEqual (nodes['D'].wins, 19)
        self.assertEqual (nodes['D'].losses, 5)
        self.assertEqual (nodes['E'].wins, 111)
        self.assertEqual (nodes['E'].losses, 8)
        self.assertEqual (nodes['B'].wins, 13)
        self.assertEqual (nodes['B'].losses, 130)
        self.assertEqual (nodes['C'].wins, 36)
        self.assertEqual (nodes['C'].losses, 27)
        self.assertEqual (nodes['A'].wins, 157)
        self.assertEqual (nodes['A'].losses, 49)

    def tearDown(self):
        return

class Test_MCNodeClass(unittest.TestCase):
    def setUp(self):
        COLS = 8
        ROWS = 8
        FILLED_ROWS = 3 
        new_board = Board(COLS, ROWS, FILLED_ROWS)
        new_board.initialize_game()
        self.A = MCNode("A", player = 1, board = new_board, move = None)

    def test_setUp(self):
        A = self.A
        self.assertEqual(A.id, "A")
        self.assertEqual(A.player, 1)
        self.assertEqual(A.board.row, 8)
        self.assertEqual(A.board.col, 8)
        self.assertEqual(A.board.p, 3)
        self.assertEqual(A.board.black_count, 12)
        self.assertEqual(A.board.white_count, 12)

    @unittest.skip("skipping to save time")
    def test_simulate(self):
        wins = 0
        wins_board = 0
        TOTAL_SIMULATIONS = 30
        for i in range(TOTAL_SIMULATIONS):
            if  i%10 == 0:
                print("test_simulate:", i)
            if self.A._simulate_test():
                wins += 1
            if self.A.simulate_random_game():
                wins_board += 1
        print("simulate:",wins, "/", TOTAL_SIMULATIONS)
        print("sim_rand:",wins_board, "/", TOTAL_SIMULATIONS)
        self.assertAlmostEqual(wins, TOTAL_SIMULATIONS/2, delta=5)
        self.assertAlmostEqual(wins_board, TOTAL_SIMULATIONS/2, delta=5)

class Test_MCTreeClass(unittest.TestCase):
    def setUp(self):
        COLS = 8
        ROWS = 8
        FILLED_ROWS = 3 
        new_board = Board(COLS, ROWS, FILLED_ROWS)
        new_board.initialize_game()
        self.A = MCNode("A", player = 1, board = new_board, move = None)
        self.MCTree = MonteCarloTree(self.A,
            expansion_policy=DeterministicPolicy)
        
    def test_setUp(self):
        A = self.A
        MCTree = self.MCTree
        self.assertEqual(A.id, "A")
        self.assertEqual(A.player, 1)
        self.assertEqual(A.board.row, 8)
        self.assertEqual(A.board.col, 8)
        self.assertEqual(A.board.p, 3)
        self.assertEqual(A.board.black_count, 12)
        self.assertEqual(A.board.white_count, 12)
        self.assertEqual(MCTree.root, A)
        self.assertAlmostEqual(MCTree.exploration_parameter, 1.414, delta=0.001)
        self.assertEqual(MCTree.expansion_policy, DeterministicPolicy.policy)

    @unittest.skip("skipping to save time")
    def test_expandNode(self):
        A = self.A
        MCTree = self.MCTree
        MCTree.expand_node(A)
        MCTree.print_tree(A)

    @unittest.skip("skipping to save time")
    def test_expandManyNodes(self):
        A = self.A
        A.children = []
        MCTree = self.MCTree
        for i in range(20):
            if(i%10 == 0):
                print("expanded the", str(i) + "th", "node!")
            MCTree.expand_node(A)
        MCTree.print_tree(A)

    def test_getBestMove(self):
        A = self.A
        A.children = []
        MCTree = self.MCTree
        for i in range(10):
            if(i%10 == 0):
                print("expanded the", str(i) + "th", "node!")
            MCTree.expand_node(A)
        MCTree.print_tree(A)
        # get best move
        previous_node = MCTree.root
        print(previous_node)
        while(len(previous_node.children) > 0):
            previous_node = previous_node.get_best_node()
            print(previous_node, ":", previous_node.win_rate())

class Test_RandomScheme(unittest.TestCase):
    def setUp(self):
        COLS = 8
        ROWS = 8
        FILLED_ROWS = 3 
        new_board = Board(COLS, ROWS, FILLED_ROWS)
        new_board.initialize_game()
        self.scheme = RandomMove(new_board)
        # test schemes in runTests?

if __name__ == "__main__":
    unittest.main()
