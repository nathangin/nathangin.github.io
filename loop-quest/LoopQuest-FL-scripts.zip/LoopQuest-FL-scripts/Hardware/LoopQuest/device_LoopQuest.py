# name=Loop Quest
#
# Loop Quest: checks your work inside FL Studio and hands you claim codes.
# Unofficial fan project, not affiliated with or endorsed by Image-Line.
#
# How it works
#   1. On a Loop Quest page, pick a real-FL quest. It has a tag like LQ04.
#   2. In FL, select a pattern, press F2 and type the tag as its name.
#   3. Follow the hint bar (the message area in FL's top toolbar). When the
#      quest is done it shows a claim code (also printed in View > Script output).
#   4. Type the code into the quest page.
#
# Testing the script: name any pattern LQ00. The hint bar says the script is
# working, and View > Script output lists what it can read from your project.
#
# Install (one time)
#   Save this file as
#     Documents/Image-Line/FL Studio/Settings/Hardware/LoopQuest/device_LoopQuest.py
#   restart FL Studio, then open Options > MIDI settings, select an input
#   (your MIDI keyboard, or a free virtual port: loopMIDI on Windows, IAC
#   Driver on macOS), click Enable and set Controller type to "Loop Quest (user)".
#
# The script only reads your project and writes to the hint bar. It never
# changes your project, and notes from your keyboard pass through as usual.
# Generated from fl/spec.json; edit the spec, not the QUESTS table below.

import channels
import mixer
import patterns
import plugins
import transport
import ui

try:
    import arrangement
except ImportError:  # very old FL versions
    arrangement = None

try:
    import general
except ImportError:
    general = None

try:
    import time as _time
except ImportError:
    _time = None

SCRIPT_VERSION = 2
QUESTS = {'lq01': {'kind': 'hello', 'title': 'Hello, FL'},
 'lq02': {'kind': 'warp', 'prompts': 6, 'title': 'Window Warp in FL'},
 'lq03': {'kind': 'tour', 'title': 'Studio tour'},
 'lq04': {'kind': 'groove',
          'rows': [{'label': 'Kick',
                    'match': 'kick',
                    'say': 'on every beat',
                    'steps': [1, 5, 9, 13]},
                   {'label': 'Clap', 'match': 'clap', 'say': 'on beats 2 and 4', 'steps': [5, 13]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'on the offbeats',
                    'steps': [3, 7, 11, 15]}],
          'tempo': [120, 128],
          'title': "DJ Nova's warm-up groove"},
 'lq05': {'check': 'scale',
          'kind': 'pianoroll',
          'minNotes': 6,
          'root': 0,
          'scale': [0, 2, 3, 5, 7, 8, 10],
          'title': 'Minor mood'},
 'lq06': {'check': 'chords',
          'chords': [{'name': 'C minor', 'pcs': [0, 3, 7]},
                     {'name': 'A flat major', 'pcs': [8, 0, 3]},
                     {'name': 'E flat major', 'pcs': [3, 7, 10]},
                     {'name': 'B flat major', 'pcs': [10, 2, 5]}],
          'kind': 'pianoroll',
          'title': "Rico's chords"},
 'lq07': {'check': 'slide808', 'kind': 'pianoroll', 'title': '808 slide'},
 'lq08': {'kind': 'markers', 'names': ['Intro', 'Verse', 'Hook'], 'title': 'Mark it up'},
 'lq09': {'kind': 'song',
          'minBars': 32,
          'names': ['Intro', 'Drop', 'Outro'],
          'title': 'One-minute song'},
 'lq10': {'kind': 'groove',
          'rows': [{'label': 'Kick', 'match': 'kick', 'say': 'on 1, 8 and 11', 'steps': [1, 8, 11]},
                   {'label': 'Snare',
                    'match': 'snare',
                    'say': 'on beats 2 and 4',
                    'steps': [5, 13]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'on every 8th note',
                    'steps': [1, 3, 5, 7, 9, 11, 13, 15]}],
          'tempo': [86, 94],
          'title': 'Boom bap groove'},
 'lq11': {'kind': 'groove',
          'rows': [{'label': 'Kick', 'match': 'kick', 'say': 'on 1, 7 and 11', 'steps': [1, 7, 11]},
                   {'label': 'Clap', 'match': 'clap', 'say': 'on beat 3', 'steps': [9]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'on every 8th note',
                    'steps': [1, 3, 5, 7, 9, 11, 13, 15]}],
          'tempo': [136, 146],
          'title': 'Trap groove'},
 'lq12': {'kind': 'groove',
          'rows': [{'label': 'Kick', 'match': 'kick', 'say': 'on 1 and 11', 'steps': [1, 11]},
                   {'label': 'Snare',
                    'match': 'snare',
                    'say': 'on beat 3, then a late hit on 12',
                    'steps': [9, 12]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'in 3-3-2',
                    'steps': [1, 4, 7, 9, 12, 15]}],
          'tempo': [140, 144],
          'title': 'Drill groove'},
 'lq13': {'kind': 'groove',
          'rows': [{'label': 'Kick',
                    'match': 'kick',
                    'say': 'on every beat',
                    'steps': [1, 5, 9, 13]},
                   {'label': 'Clap', 'match': 'clap', 'say': 'on beats 2 and 4', 'steps': [5, 13]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'on the offbeats',
                    'steps': [3, 7, 11, 15]},
                   {'label': 'Snare',
                    'match': 'snare',
                    'say': 'as pickups on 8 and 16',
                    'steps': [8, 16]}],
          'tempo': [120, 124],
          'title': 'Deep house groove'},
 'lq14': {'kind': 'groove',
          'rows': [{'label': 'Kick', 'match': 'kick', 'say': 'on 1, 8 and 11', 'steps': [1, 8, 11]},
                   {'label': 'Clap', 'match': 'clap', 'say': 'on beat 3', 'steps': [9]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'on the offbeats',
                    'steps': [3, 7, 11, 15]}],
          'tempo': [145, 155],
          'title': 'Future bass drums'},
 'lq15': {'kind': 'groove',
          'rows': [{'label': 'Kick', 'match': 'kick', 'say': 'on 1 and 12', 'steps': [1, 12]},
                   {'label': 'Snare', 'match': 'snare', 'say': 'on beat 3', 'steps': [9]},
                   {'label': 'Hat',
                    'match': 'hat',
                    'say': 'on every 8th note',
                    'steps': [1, 3, 5, 7, 9, 11, 13, 15]}],
          'tempo': [138, 142],
          'title': 'Dubstep drums'},
 'lq16': {'channels': ['Bass'], 'kind': 'synth', 'title': 'Load a synth'},
 'lq17': {'channels': ['Bass', 'Lead'], 'kind': 'synth', 'title': 'Bass and lead'},
 'lq18': {'channels': ['Kick', 'Clap', 'Hat'], 'kind': 'routing', 'title': 'Route the drums'},
 'lq19': {'bars': 8, 'eqOn': 'Kick', 'kind': 'mixfx', 'title': 'Clean mix'},
 'lq20': {'bars': 16, 'kind': 'noclip', 'title': 'No Clip Zone'},
 'lq21': {'anchor': 'Kick',
          'belowDb': 3,
          'center': ['Kick', 'Clap'],
          'centerMax': 0.05,
          'kind': 'panmix',
          'minPan': 0.2,
          'quieter': ['Hat'],
          'sides': ['Hat', 'Snare'],
          'title': 'Pan and balance'},
 'lq22': {'kind': 'record', 'title': 'Ready to record'}}

STEPS = 16
WID_MIXER, WID_CHANNEL_RACK, WID_PLAYLIST, WID_PIANO_ROLL, WID_BROWSER = 0, 1, 2, 3, 4
WINDOWS = {
    WID_MIXER: ("Mixer", "F9"),
    WID_CHANNEL_RACK: ("Channel Rack", "F6"),
    WID_PLAYLIST: ("Playlist", "F5"),
    WID_PIANO_ROLL: ("Piano Roll", "F7"),
    WID_BROWSER: ("Browser", "Alt+F8"),
}
TICKS_SLOW = 25        # OnIdle runs about every 20 ms: about twice a second
TICKS_FAST = 5         # about ten times a second for timed quests
FAST_KINDS = ("warp", "tour", "mixfx", "noclip")
REASSERT_SECONDS = 4.0 # show our hint again if FL replaced it
HINT_AFTER = 4.0       # seconds before a key hint appears in timed drills
HIGHLIGHT_MS = 30000
CLIP_LEVEL = 1.001     # 1.0 is 0 dBFS

CODE_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"  # Crockford base32


# ---------------------------------------------------------------- claim codes

def fnv1a32(text):
    """32-bit FNV-1a hash of a UTF-8 string. Mirrors fnv1a32() in the page."""
    h = 0x811C9DC5
    for byte in text.encode("utf-8"):
        h ^= byte
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h


def mix32(h):
    """Scramble all 32 bits so nearby values give unrelated codes."""
    h ^= h >> 16
    h = (h * 0x85EBCA6B) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * 0xC2B2AE35) & 0xFFFFFFFF
    h ^= h >> 16
    return h


def claim_code(quest_id, variant):
    """Claim code for a finished quest. variant is the tempo, or 0."""
    h = mix32(fnv1a32("LQ1|%s|%d" % (quest_id, variant)))
    chars = []
    for _ in range(7):
        chars.append(CODE_ALPHABET[h & 31])
        h >>= 5
    body = "".join(chars)
    return "LQ-%s-%s" % (body[:3], body[3:])


# ---------------------------------------------------------------- session

class Session:
    def __init__(self):
        self.reset()

    def reset(self):
        self.ticks = 0
        self.clock = 0.0          # fallback clock when the time module is missing
        self.tag = None
        self.st = {}
        self.codes = {}           # tag -> (variant, code)
        self.message = ""
        self.shown_at = 0.0
        self.highlight_row = -1
        self.highlight_at = 0.0
        self.warned = False
        self.seed = 1234567


session = Session()


def now():
    if _time is not None:
        try:
            return _time.time()
        except Exception:
            pass
    return session.clock


def rand(n):
    """Small deterministic PRNG, so the script needs no random module."""
    session.seed = (session.seed * 1103515245 + 12345 + int(now() * 1000)) & 0x7FFFFFFF
    return session.seed % n


def result(done=False, msg="", variant=0, row=-1, ready=False):
    return {"done": done, "msg": msg, "variant": variant, "row": row, "ready": ready}


# ---------------------------------------------------------------- FL readers

def parse_tag(name):
    """Find a quest tag like LQ04 in a pattern name. Returns 'lq04' or None."""
    s = "".join(ch for ch in str(name).upper() if ch.isalnum())
    i = s.find("LQ")
    while i >= 0:
        digits = ""
        j = i + 2
        while j < len(s) and s[j].isdigit() and len(digits) < 2:
            digits += s[j]
            j += 1
        if digits:
            return "lq%02d" % int(digits)
        i = s.find("LQ", i + 1)
    return None


def read_tag():
    try:
        return parse_tag(patterns.getPatternName(patterns.patternNumber()))
    except Exception:
        return None


def find_channel(keyword):
    keyword = keyword.lower()
    for index in range(channels.channelCount()):
        if keyword in str(channels.getChannelName(index)).lower():
            return index
    return -1


def steps_on(index):
    return [pos + 1 for pos in range(STEPS) if channels.getGridBit(index, pos)]


def tempo():
    bpm = float(mixer.getCurrentTempo())
    if bpm > 1000:  # guard: some API versions report tempo x 1000
        bpm /= 1000.0
    return bpm


def focused_window():
    for index in WINDOWS:
        try:
            if ui.getFocused(index):
                return index
        except Exception:
            pass
    return -1


def rack_open():
    try:
        return bool(ui.getVisible(WID_CHANNEL_RACK) or ui.getFocused(WID_CHANNEL_RACK))
    except Exception:
        return True


def song_mode():
    return transport.getLoopMode() == 1


def marker_names():
    names = []
    if arrangement is None:
        return names
    for index in range(32):
        try:
            name = arrangement.getMarkerName(index)
        except Exception:
            break
        if name:
            names.append(str(name).lower())
    return names


def slot_plugins(track):
    names = []
    for slot in range(10):
        try:
            if plugins.isValid(track, slot):
                names.append(str(plugins.getPluginName(track, slot)).lower())
        except Exception:
            pass
    return names


def is_eq(name):
    words = "".join(ch if ch.isalnum() else " " for ch in name).split()
    return any(w.startswith("eq") for w in words) or "pro-q" in name or "pro q" in name


def is_limiter(name):
    return "limiter" in name or "maximus" in name or "clipper" in name


def master_peak():
    # getTrackPeaks: 0.0 silence, 1.0 = 0 dB, above 1.0 = clipping.
    try:
        return float(mixer.getTrackPeaks(0, 2))
    except Exception:
        pass
    peak = 0.0
    for side in (0, 1):
        try:
            peak = max(peak, float(mixer.getLastPeakVol(side)))
        except Exception:
            pass
    return peak


def words_list(items):
    items = list(items)
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]


def numbers(word, items):
    """'add step 9' or 'add steps 9, 13'."""
    return "%s%s %s" % (word, "s" if len(items) > 1 else "", ", ".join(str(i) for i in items))


def clean_play(st, bars):
    """Track how long playback has run without the master clipping.
    Returns 'stopped', 'clip', or a fraction of the target (1.0 = done)."""
    if not transport.isPlaying():
        st["clean"] = 0.0
        st["last"] = None
        return "stopped"
    t = now()
    if st.get("last") is not None:
        st["clean"] = st.get("clean", 0.0) + max(0.0, t - st["last"])
    st["last"] = t
    if master_peak() > CLIP_LEVEL:
        st["clean"] = 0.0
        st["clipped_at"] = t
        return "clip"
    need = bars * 4 * 60.0 / max(40.0, tempo())
    return min(1.0, st.get("clean", 0.0) / need)


def clean_message(state, bars):
    if state == "stopped":
        return "Press Space and let it play for %d bars" % bars
    if state == "clip":
        return "The master clipped! Turn down the loudest track or the master, then play on"
    return "Playing clean: %d of %d bars" % (int(state * bars), bars)


# ---------------------------------------------------------------- quest checks

def check_hello(q, st):
    if transport.isPlaying():
        return result(done=True)
    return result(msg="Quest found! Press Space to play", ready=True)


def check_warp(q, st):
    total = int(q.get("prompts", 6))
    if "i" not in st:
        st.update(i=0, target=None, prev=None, t_prompt=now(), t_start=None, elapsed=0.0)
    if st["i"] >= total:
        return result(done=True, msg="%d windows in %.1f s" % (total, st["elapsed"]))
    focused = focused_window()
    if st["target"] is None:
        options = [w for w in WINDOWS if w != focused and w != st["prev"]]
        st["target"] = options[rand(len(options))]
        st["t_prompt"] = now()
        if st["t_start"] is None:
            st["t_start"] = st["t_prompt"]
    if focused == st["target"]:
        st["i"] += 1
        st["prev"] = st["target"]
        st["target"] = None
        if st["i"] >= total:
            st["elapsed"] = now() - st["t_start"]
            return result(done=True, msg="%d windows in %.1f s" % (total, st["elapsed"]))
        return result(msg="Nice! %d of %d" % (st["i"], total))
    name, key = WINDOWS[st["target"]]
    hint = " (%s)" % key if now() - st["t_prompt"] > HINT_AFTER else ""
    return result(msg="%d/%d: open the %s%s" % (st["i"] + 1, total, name, hint))


TOUR_STEPS = (
    ("Turn on the metronome", "Ctrl+M", lambda: bool(ui.isMetronomeEnabled())),
    ("Switch to Song mode", "L", lambda: song_mode()),
    ("Switch back to Pattern mode", "L", lambda: not song_mode()),
    ("Open the Mixer", "F9", lambda: bool(ui.getFocused(WID_MIXER))),
    ("Open the Playlist", "F5", lambda: bool(ui.getFocused(WID_PLAYLIST))),
    ("Press play", "Space", lambda: bool(transport.isPlaying())),
)


def check_tour(q, st):
    if "i" not in st:
        st.update(i=0, t_step=now())
    total = len(TOUR_STEPS)
    while st["i"] < total and TOUR_STEPS[st["i"]][2]():
        st["i"] += 1
        st["t_step"] = now()
    if st["i"] >= total:
        return result(done=True)
    label, key, _ = TOUR_STEPS[st["i"]]
    hint = " (%s)" % key if now() - st["t_step"] > HINT_AFTER else ""
    return result(msg="Step %d/%d: %s%s" % (st["i"] + 1, total, label, hint))


def check_groove(q, st):
    if not rack_open():
        return result(msg="Press F6 to open the Channel Rack")
    for row in q["rows"]:
        index = find_channel(row["match"])
        if index < 0:
            return result(msg="No %s channel. Start a new project, or rename a channel %s"
                          % (row["label"], row["label"]))
        on = steps_on(index)
        missing = [s for s in row["steps"] if s not in on]
        extra = [s for s in on if s not in row["steps"]]
        if missing or extra:
            fixes = []
            if missing:
                fixes.append(numbers("add step", missing))
            if extra:
                fixes.append(numbers("remove step", extra))
            say = (" " + row["say"]) if row.get("say") else ""
            return result(msg="%s%s: %s" % (row["label"], say, "; ".join(fixes)), row=index)
    low, high = q["tempo"]
    bpm = tempo()
    whole = int(round(bpm))
    if abs(bpm - whole) > 0.05:
        return result(msg="Tempo is %.2f. Use a whole number, like %d" % (bpm, (low + high) // 2))
    if not low <= whole <= high:
        return result(msg="Now set the tempo from the brief (%d to %d BPM)" % (low, high))
    if transport.isPlaying():
        return result(done=True, variant=whole)
    return result(msg="Groove ready at %d BPM. Press Space to hear it" % whole, variant=whole, ready=True)


def check_pianoroll(q, st):
    return result(msg="Checked in the Piano Roll: open it (F7), then Tools > Script list > Loop Quest Check")


def check_markers(q, st):
    names = marker_names()
    missing = [n for n in q["names"] if not any(n.lower() in m for m in names)]
    if missing:
        return result(msg="Add Playlist markers (Alt+T) named %s. Missing: %s"
                      % (words_list(q["names"]), words_list(missing)))
    if not song_mode():
        return result(msg="Markers done. Switch to Song mode (L)")
    if transport.isPlaying():
        return result(done=True)
    return result(msg="Markers done. Press Space to play the song", ready=True)


def check_song(q, st):
    bars = 0
    try:
        bars = int(transport.getSongLength(3))
    except Exception:
        pass
    if bars < q["minBars"]:
        return result(msg="Song is %d bars. Arrange patterns in the Playlist to reach %d"
                      % (bars, q["minBars"]))
    names = marker_names()
    missing = [n for n in q["names"] if not any(n.lower() in m for m in names)]
    if missing:
        return result(msg="%d bars, nice. Add markers (Alt+T): %s" % (bars, words_list(missing)))
    if not song_mode():
        return result(msg="Switch to Song mode (L) so the Playlist plays")
    if transport.isPlaying():
        return result(done=True)
    return result(msg="Song ready at %d bars. Press Space" % bars, ready=True)


def check_synth(q, st):
    for name in q["channels"]:
        index = find_channel(name)
        if index < 0:
            return result(msg="Add a synth channel (3x Osc or FLEX) and rename it %s" % name)
        try:
            ok = plugins.isValid(index)
        except Exception:
            ok = False
        if not ok:
            return result(msg="%s needs a synth plugin like 3x Osc or FLEX, not a sample" % name,
                          row=index)
    if transport.isPlaying():
        return result(done=True)
    return result(msg="%s ready. Press Space" % words_list(q["channels"]), ready=True)


def check_routing(q, st):
    used = {}
    tracks = []
    for name in q["channels"]:
        index = find_channel(name)
        if index < 0:
            return result(msg="No %s channel. Start a new project" % name)
        track = int(channels.getTargetFxTrack(index))
        if track <= 0:
            return result(msg="Route %s to its own mixer track: select it, press Ctrl+L" % name,
                          row=index)
        if track in used:
            return result(msg="%s and %s share insert %d. Give each its own track"
                          % (used[track], name, track), row=index)
        used[track] = name
        tracks.append((name, track))
    for name, track in tracks:
        if name.lower() not in str(mixer.getTrackName(track)).lower():
            return result(msg="Name insert %d \"%s\": select it in the Mixer, press F2" % (track, name))
    return result(done=True)


def check_mixfx(q, st):
    name = q.get("eqOn", "Kick")
    index = find_channel(name)
    if index < 0:
        return result(msg="No %s channel. Start a new project" % name)
    track = int(channels.getTargetFxTrack(index))
    if track <= 0:
        return result(msg="Route %s to its own mixer track first (Ctrl+L)" % name, row=index)
    if not any(is_eq(p) for p in slot_plugins(track)):
        return result(msg="Add Fruity Parametric EQ 2 to insert %d (%s)" % (track, name))
    if not any(is_limiter(p) for p in slot_plugins(0)):
        return result(msg="Add Fruity Limiter to the Master track")
    state = clean_play(st, q["bars"])
    if state == 1.0:
        return result(done=True)
    return result(msg=clean_message(state, q["bars"]))


def pan_text(pan):
    """-0.3 -> '30% left'."""
    amount = int(round(abs(pan) * 100))
    if amount == 0:
        return "centered"
    return "%d%% %s" % (amount, "left" if pan < 0 else "right")


def track_db(track):
    """A mixer track's fader in dB, or None on API versions without the dB mode."""
    try:
        return float(mixer.getTrackVolume(track, 1))
    except TypeError:
        return None


def db_text(db):
    if db != db or db < -200:  # NaN or silence
        return "-inf dB"
    return "%+.1f dB" % db if abs(db) >= 0.05 else "0.0 dB"


def check_panmix(q, st):
    tracks = {}
    used = {}
    for name in q["center"] + q["sides"]:
        index = find_channel(name)
        if index < 0:
            return result(msg="No %s channel. Start a new project" % name)
        track = int(channels.getTargetFxTrack(index))
        if track <= 0:
            return result(msg="Route %s to its own mixer track: select it, press Ctrl+L" % name, row=index)
        if track in used:
            return result(msg="%s and %s share insert %d. Give each its own track"
                          % (used[track], name, track), row=index)
        used[track] = name
        tracks[name] = track
    for name in q["center"]:
        pan = float(mixer.getTrackPan(tracks[name]))
        if abs(pan) > q["centerMax"]:
            return result(msg="Keep the %s in the middle: its mixer track is panned %s"
                          % (name, pan_text(pan)))
    pans = dict((name, float(mixer.getTrackPan(tracks[name]))) for name in q["sides"])
    need = int(round(q["minPan"] * 100))
    for name in q["sides"]:
        if abs(pans[name]) < q["minPan"]:
            return result(msg="Pan the %s's mixer track at least %d%% left or right (now %s)"
                          % (name, need, pan_text(pans[name])))
    first, second = q["sides"][0], q["sides"][1]
    if (pans[first] < 0) == (pans[second] < 0):
        return result(msg="Pan the %s and %s to opposite sides (both are %s)"
                      % (first, second, "left" if pans[first] < 0 else "right"))
    anchor = q["anchor"]
    anchor_db = track_db(tracks[anchor])
    for name in q["quieter"]:
        this_db = track_db(tracks[name])
        if anchor_db is None or this_db is None:
            # No decibels on this FL: compare the fader positions instead.
            if float(mixer.getTrackVolume(tracks[name])) >= float(mixer.getTrackVolume(tracks[anchor])) - 0.05:
                return result(msg="Pull the %s's fader down, below the %s's" % (name, anchor))
        elif this_db > anchor_db - q["belowDb"]:
            return result(msg="Pull the %s's fader down to at least %d dB under the %s's (%s %s, %s %s)"
                          % (name, q["belowDb"], anchor, anchor, db_text(anchor_db), name, db_text(this_db)))
    if not transport.isPlaying():
        return result(msg="Mix set: middle, sides and levels all check out. Press Space", ready=True)
    return result(done=True)


def armed_tracks():
    armed = []
    try:
        count = int(mixer.trackCount())
    except Exception:
        count = 127
    for track in range(1, count):
        try:
            if mixer.isTrackArmed(track):
                armed.append(track)
        except Exception:
            break
    return armed


def check_record(q, st):
    armed = armed_tracks()
    if not armed:
        return result(msg="Arm a mixer track: pick an Input for it, or click its recording arm switch (the disk icon under the fader)")
    if not transport.isRecording():
        return result(msg="Insert %d is armed. Press R to turn recording on" % armed[0])
    if not transport.isPlaying():
        return result(msg="Recording is on. Press Space to start the take", ready=True)
    return result(done=True)


def check_noclip(q, st):
    if not song_mode():
        st["clean"] = 0.0
        st["last"] = None
        return result(msg="Switch to Song mode (L) and play your song")
    state = clean_play(st, q["bars"])
    if state == 1.0:
        return result(done=True)
    return result(msg=clean_message(state, q["bars"]))


CHECKS = {
    "hello": check_hello,
    "warp": check_warp,
    "tour": check_tour,
    "groove": check_groove,
    "pianoroll": check_pianoroll,
    "markers": check_markers,
    "song": check_song,
    "synth": check_synth,
    "routing": check_routing,
    "mixfx": check_mixfx,
    "panmix": check_panmix,
    "record": check_record,
    "noclip": check_noclip,
}


# ---------------------------------------------------------------- diagnostics

def read_markers_check():
    if arrangement is None:
        return "not available in this FL version"
    names = marker_names()
    return "%d found%s" % (len(names), (": " + ", ".join(names[:6])) if names else "")


def diagnostics():
    """LQ00: report what the script can read, so problems are easy to spot."""
    lines = []
    values = {}

    def add(key, label, fn):
        try:
            value = fn()
        except Exception as error:
            value = None
            lines.append("  %s: can't read (%s)" % (label, error))
        else:
            lines.append("  %s: %s" % (label, value))
        values[key] = value

    add("fl", "FL Studio version", lambda: ui.getVersion())
    add("api", "Scripting API version", lambda: general.getVersion() if general is not None else "unknown")
    add("script", "Loop Quest script version", lambda: SCRIPT_VERSION)
    add("tempo", "Tempo", lambda: "%.1f BPM" % tempo())
    add("pattern", "Pattern", lambda: "%d, named %s" % (patterns.patternNumber(), patterns.getPatternName(patterns.patternNumber())))
    add("channels", "Channels", lambda: channels.channelCount())
    add("names", "Channel names", lambda: ", ".join(str(channels.getChannelName(i)) for i in range(min(12, channels.channelCount()))))
    add("mode", "Mode", lambda: "Song" if song_mode() else "Pattern")
    add("playing", "Playing", lambda: "yes" if transport.isPlaying() else "no")
    add("window", "Focused window", lambda: WINDOWS[focused_window()][0] if focused_window() in WINDOWS else "none of the five")
    add("peak", "Master peak (1.00 = 0 dB)", lambda: "%.2f" % master_peak())
    add("markers", "Playlist markers", read_markers_check)
    failed = sum(1 for line in lines if "can't read" in line)
    summary = "Loop Quest v%d is working. Scripting API %s, %s, %s channels" % (
        SCRIPT_VERSION, values.get("api") or "?", values.get("tempo") or "tempo unknown", values.get("channels") if values.get("channels") is not None else "?")
    if failed:
        summary += ". %d reading%s failed: see View > Script output" % (failed, "" if failed == 1 else "s")
    else:
        summary += ". Details in View > Script output"
    return summary, lines


# ---------------------------------------------------------------- main loop

def start_quest(tag):
    session.tag = tag
    session.st = {}
    print("Loop Quest: %s %s started" % (tag.upper(), QUESTS[tag]["title"]))


def check():
    tag = read_tag()
    if tag == "lq00":
        if session.tag != "lq00":
            session.tag = "lq00"
            session.st = {}
            summary, lines = diagnostics()
            session.st["summary"] = summary
            print("Loop Quest diagnostics (LQ00)\n" + "\n".join(lines))
        show(session.st.get("summary", "Loop Quest is working"))
        highlight(-1)
        return
    if session.tag == "lq00":  # left the diagnostics pattern
        session.tag = None
    if tag and tag != session.tag:
        if tag in QUESTS:
            start_quest(tag)
        else:
            show("Loop Quest: %s isn't a quest tag. Check the tag on the quest page" % tag.upper())
            highlight(-1)
            return
    if session.tag is None:
        show("Loop Quest: select a pattern, press F2 and name it with your quest tag, like LQ01")
        highlight(-1)
        return

    q = QUESTS[session.tag]
    label = session.tag.upper()
    res = CHECKS[q["kind"]](q, session.st)
    variant = res["variant"] or 0

    if res["done"]:
        code = claim_code(session.tag, variant)
        if session.codes.get(session.tag) != (variant, code):
            session.codes[session.tag] = (variant, code)
            print("Loop Quest: %s complete%s. Claim code: %s"
                  % (label, (" at %d BPM" % variant) if variant else "", code))

    saved = session.codes.get(session.tag)
    if saved:
        if res["ready"] and variant and variant != saved[0]:
            message = "%s: tempo is now %d BPM. Press Space for a new claim code" % (label, variant)
        else:
            extra = (" (%d BPM)" % saved[0]) if saved[0] else ""
            detail = (" " + res["msg"] + ".") if res["done"] and res["msg"] else ""
            message = "%s complete!%s Claim code %s%s" % (label, detail, saved[1], extra)
        row = -1
    else:
        message = "%s: %s" % (label, res["msg"])
        row = res["row"]

    show("Loop Quest " + message)
    highlight(row)


def show(message):
    """Put our message in the hint bar, and log each new one to Script output."""
    t = now()
    if message != session.message:
        session.message = message
        session.shown_at = t
        ui.setHintMsg(message)
        print(message)
        return
    if t - session.shown_at >= REASSERT_SECONDS:
        session.shown_at = t
        try:
            if ui.getHintMsg() != message:
                ui.setHintMsg(message)
        except Exception:
            ui.setHintMsg(message)


def highlight(row):
    """Outline the Channel Rack row that needs fixing (best effort)."""
    try:
        t = now()
        if row >= 0:
            if row != session.highlight_row or t - session.highlight_at > HIGHLIGHT_MS / 2000.0:
                ui.crDisplayRect(0, row, STEPS, 1, HIGHLIGHT_MS)
                session.highlight_row = row
                session.highlight_at = t
        elif session.highlight_row >= 0:
            ui.crDisplayRect(0, 0, 0, 0, 0)
            session.highlight_row = -1
    except Exception:
        session.highlight_row = -1


def OnInit():
    session.reset()
    message = "Loop Quest v%d connected. Name a pattern with your quest tag (F2), like LQ01" % SCRIPT_VERSION
    session.message = message
    session.shown_at = now()
    ui.setHintMsg(message)
    print(message)


def OnDeInit():
    highlight(-1)


def OnIdle():
    session.ticks += 1
    session.clock += 0.02
    kind = QUESTS[session.tag]["kind"] if session.tag in QUESTS else ""
    if session.ticks < (TICKS_FAST if kind in FAST_KINDS else TICKS_SLOW):
        return
    session.ticks = 0
    try:
        check()
    except Exception as error:
        if not session.warned:
            session.warned = True
            print("Loop Quest: a check failed (%s). Note your FL Studio version "
                  "and report it." % error)
